﻿# SwiftFilter
Exchange Transport rules using text matching and Regular Expressions to detect and enable response to basic phishing. Designed to augment EOP in Office 365.

The reason that spam filters do not integrate these detections, which they easily could, is because they REQUIRE TUNING. Every company is different and has different lexicon and business practices.

They require daily monitoring and updating to address ever-changing threats. However, after about two years of working on these, they've reached a high level of maturity.